from .common import ArtifactSchema, BaseSchema
