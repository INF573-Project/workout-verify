# Field type flags
FIELD_PERSISTANCE = "field_persistance"
FIELD_PERISH_STAGE = "field_perish_stage"
